<?php

namespace SPERanks;

/*
                            Hola :V
       Dame creditos si lo vas a editar y subirlo a internet
                   Youtube.com/c/CortuahGamer
                              =D
                    400 LINEAS DE CODIGO!!
*/

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\command\{Command, CommandSender};
use pocketmine\utils\TextFormat as C;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\sound\EndermanTeleportSound;

class SPERanks extends PluginBase implements Listener{

private $attachments = [];
public $ranks = array();

public function onEnable(){
   $this->getServer()->getPluginManager()->registerEvents($this, $this);
   $this->getLogger()->info(C::GREEN . "SPE-Ranks Enable");
   @mkdir($this->getDataFolder());

   $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
   $rank->save();
   $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
   $srank->save();

   @mkdir($this->getDataFolder()."/Config");

   $ranks = new Config($this->getDataFolder()."ranks.yml", Config::YAML);
   if($ranks->get("ranks") == null){
   $ranks->set("ranks", array("YouTuber", "MiniYT", "Famous", "Fighter",
    "Master", "Builder", "Helper",
     "Mod", "Admin", "Owner"));
   $ranks->save();
   }
   $this->ranks = $ranks->get("ranks");
   $totales = $this->ranks;
   foreach($totales as $rango){
   $total = new Config($this->getDataFolder()."Config/".$rango.".yml", Config::YAML, []);

   if($total->get("perms") == null){
     $total->set("prefix", "§8[§aPREFIX§8]§b");
     $total->set("Mensaje", "§a");
     $total->set("perms", array("perm.command.perm"));
     $total->save();
   }}
 }

   public function onRespawn(PlayerRespawnEvent $ev){
     $player = $ev->getPlayer();
    $this->Pranks($player);
  }

  public function onJoin(PlayerJoinEvent $event){
    $player = $event->getPlayer();
    $event->setJoinMessage("");
    $this->Pranks($player);

    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $r = $rank->get($player->getName());

    $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
    $sr = $srank->get($player->getName());

    if (($sr=="youtube")||($sr=="YouTube")||($sr=="youtuber")||($sr=="YouTuber")) {
       $attachment = $this->getAttachment($player);
       $total = new Config($this->getDataFolder()."/Config/YouTuber.yml", Config::YAML);
  $perms = $total->get("perms");
  foreach($perms as $perm){
  $attachment->setPermission($perm, true);
  }}
  if (($sr=="famous")||($sr=="Famous")) {
     $attachment = $this->getAttachment($player);
     $total = new Config($this->getDataFolder()."/Config/Famous.yml", Config::YAML);
     $perms = $total->get("perms");
     foreach($perms as $perm){
     $attachment->setPermission($perm, true);
     } }
   if (($sr=="miniyt")||($sr=="MiniYT")){
      $attachment = $this->getAttachment($player);
      $total = new Config($this->getDataFolder()."/Config/MiniYT.yml", Config::YAML);
      $perms = $total->get("perms");
      foreach($perms as $perm){
      $attachment->setPermission($perm, true);
      }  }
      if (($r=="Fighter")||($r=="fighter")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Fighter.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
      if (($r=="Master")||($r=="master")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Master.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }  }
      if (($r=="Guardian")||($r=="guardian")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Guardian.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
      if (($r=="Builder")||($r=="builder")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Builder.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
      if (($r=="Helper")||($r=="helper")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Helper.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
      if (($r=="Mod")||($r=="mod")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Mod.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
      if (($r=="Admin")||($r=="admin")) {
        $attachment = $this->getAttachment($player);
        $total = new Config($this->getDataFolder()."/Config/Admin.yml", Config::YAML);
        $perms = $total->get("perms");
        foreach($perms as $perm){
        $attachment->setPermission($perm, true);
        }   }
  }

public function onQuit(PlayerQuitEvent $event){
  $player = $event->getPlayer();
  $event->setQuitMessage("");

  $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
  $r = $rank->get($player->getName());

  $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
  $sr = $srank->get($player->getName());

if(($sr=="miniyt")||($sr=="MiniYT")){
  unset($this->attachments[$player->getName()]);
}
if (($sr=="youtube")||($sr=="YouTube")||($sr=="youtuber")||($sr=="YouTuber")) {
  unset($this->attachments[$player->getName()]);
}
if (($sr=="famous")||($sr=="Famous")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="guardian")||($r=="Guardian")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Master")||($r=="master")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Fighter")||($r=="fighter")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Builder")||($r=="builder")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Helper")||($r=="helper")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Mod")||($r=="mod")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Admin")||($r=="admin")) {
  unset($this->attachments[$player->getName()]);
}
if (($r=="Owner")||($r=="owner")) {
  unset($this->attachments[$player->getName()]);
}}

public function onChat(PlayerChatEvent $ev){
  $player = $ev->getPlayer();
  $message = $ev->getMessage();

  $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
  $r = $rank->get($player->getName());
  $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
  $sr = $srank->get($player->getName());

  if (($sr=="miniyt")||($sr=="MiniYT")) {
    $total = new Config($this->getDataFolder()."/Config/MiniYT.yml", Config::YAML);
    $prefix = $total->get("prefix");
    $msj = $total->get("Mensaje");
    $ev->setFormat($prefix.$player->getDisplayName()." ".$msj.$message);
  }
  elseif (($sr=="youtube")||($sr=="YouTube")||($sr=="youtuber")||($sr=="YouTuber")) {
    $total = new Config($this->getDataFolder()."/Config/YouTuber.yml", Config::YAML);
    $prefix = $total->get("prefix");
    $msj = $total->get("Mensaje");
    $ev->setFormat($prefix.$player->getDisplayName()." ".$msj.$message);
  }
  elseif (($sr=="famous")||($sr=="Famous")) {
    $total = new Config($this->getDataFolder()."/Config/Famous.yml", Config::YAML);
    $prefix = $total->get("prefix");
    $msj = $total->get("Mensaje");
    $ev->setFormat($prefix.$player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="fighter")||($r=="Fighter")) {
    $total = new Config($this->getDataFolder()."/Config/Fighter.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif(($r=="guardian")||($r=="Guardian")){
    $total = new Config($this->getDataFolder()."/Config/Guardian.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="master")||($r=="Master")) {
    $total = new Config($this->getDataFolder()."/Config/Master.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="builder")||($r=="Builder")) {
    $total = new Config($this->getDataFolder()."/Config/Builder.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="helper")||($r=="Helper")) {
    $total = new Config($this->getDataFolder()."/Config/Helper.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="mod")||($r=="Mod")) {
    $total = new Config($this->getDataFolder()."/Config/Mod.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="Admin")||($r=="admin")) {
    $total = new Config($this->getDataFolder()."/Config/Admin.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  }
  elseif (($r=="owner")||($r=="Owner")) {
    $total = new Config($this->getDataFolder()."/Config/Owner.yml", Config::YAML);
    $msj = $total->get("Mensaje");
    $ev->setFormat($player->getDisplayName()." ".$msj.$message);
  } else {
  $ev->setFormat("§8[§aUser§8] §7".$player->getName()." §7".$message);
}
}

public function onCommand(CommandSender $player, Command $cmd, String $label, array $args) : bool {
	if($cmd->getName() == "delrank"){
		if (isset($args[0]) == false){
					$player->sendMessage("§aUsage: /delrank <name>");
					return true;
				}
		$rr = new Config($this->getDataFolder()."/rank.yml",Config::YAML);
  $rank->remove($args[0]);
  $player->sendMessage("§aRemove Rank Of §e".$args[0]."§a Successfully");
	}elseif($cmd->getName() == "setrank"){
    if($player->hasPermission("spe.staff.op")){
		if (isset($args[0]) == false){
					$player->sendMessage("§aUsage: /setname <name> <rank>");
					return true;
				}
      if (isset($args[0])) {
          $jug = $player->getServer()->getPlayer($args[0]);
          if($jug!=null){
  if(isset($args[1])){$motivo = implode(" ", $args);  $worte = explode(" ", $motivo);  unset($worte[0]);
  $motivo = implode(" ", $worte);

  $rank = new Config($this->getDataFolder()."/rank.yml",Config::YAML);
  $rank->set($jug->getName(), $motivo);
  $rank->save();
  $this->Pranks($jug);

  //$jug->addTitle("§bSpoky§ePE §dNetwork", "§aRank $motivo", 20, 40, 20);
  $player->sendMessage("§7Se You set »§a ". $motivo. "§7 foreach »§a".$jug->getName());
  $player->sendMessage("§aList Rank: §6Fighter, Guardian, Master, Builder, Helper, Mod, Admin, Owner, §6MiniYT, YouTuber, Famous");
  }} else {
  $player->sendMessage("§Player Not Found");
  }}}
  }
/*
  if($cmd->getName() == "setsrank"){
    if($player->hasPermission("spe.staff")){
      if (isset($args[0])) {
          $jug = $player->getServer()->getPlayer($args[0]);
          if($jug!=null){
  if(isset($args[1])){  $motivo = implode(" ", $args);  $worte = explode(" ", $motivo);  unset($worte[0]);
  $motivo = implode(" ", $worte);

  $srank = new Config($this->getDataFolder()."/srank.yml",Config::YAML);
  $srank->set($jug->getName(), $motivo);
  $srank->save();
  $this->Pytranks($jug);

  $jug->addTitle("§bSpoky§ePE §dNetwork", "§aRank $motivo", 20, 40, 20);
  $player->sendMessage("§7Se a dado rango »§a ". $motivo. "§7 To »§a".$jug->getName());
  $player->sendMessage("§l§cAlert §f» §r§eSRanks disponibles: §6MiniYT, YouTuber, Famous");
  }} else {
  $player->sendMessage("§Player Not Found");
  }}}
  }*/
  return true;
}

public function getAttachment(Player $player){
if(!isset($this->attachments[$player->getName()])){
$this->attachments[$player->getName()] = $player->addAttachment($this);}
return $this->attachments[$player->getName()];
}

public function Pranks($player) {

    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $r = $rank->get($player->getName());
    $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
    $sr = $srank->get($player->getName());

    if(($r=="Owner")||($r=="owner")){
      $total = new Config($this->getDataFolder()."/Config/Owner.yml", Config::YAML);
      $prefix = $total->get("prefix");
      $player->setDisplayName($prefix.$player->getName());
      $player->setNameTag($prefix.$player->getName());    }
    elseif(($r=="Admin")||($r=="admin")){
      $total = new Config($this->getDataFolder()."/Config/Admin.yml", Config::YAML);
      $prefix = $total->get("prefix");
      $player->setDisplayName($prefix.$player->getName());
      $player->setNameTag($prefix.$player->getName());    }
     elseif(($r=="Mod")||($r=="mod")){
        $total = new Config($this->getDataFolder()."/Config/Mod.yml", Config::YAML);
        $prefix = $total->get("prefix");
        $player->setDisplayName($prefix.$player->getName());
        $player->setNameTag($prefix.$player->getName());    }
       elseif(($r=="helper")||($r=="Helper")){
          $total = new Config($this->getDataFolder()."/Config/Helper.yml", Config::YAML);
          $prefix = $total->get("prefix");
          $player->setDisplayName($prefix.$player->getName());
          $player->setNameTag($prefix.$player->getName());  }
          elseif(($r=="Builder")||($r=="builder")){
            $total = new Config($this->getDataFolder()."/Config/Builder.yml", Config::YAML);
            $prefix = $total->get("prefix");
            $player->setDisplayName($prefix.$player->getName());
            $player->setNameTag($prefix.$player->getName());   }
            elseif(($r=="Fighter")||($r=="fighter")){
              $total = new Config($this->getDataFolder()."/Config/Fighter.yml", Config::YAML);
              $prefix = $total->get("prefix");
              $player->setDisplayName($prefix.$player->getName());
              $player->setNameTag($prefix.$player->getName());    }
              elseif(($r=="Master")||($r=="master")){
                $total = new Config($this->getDataFolder()."/Config/Master.yml", Config::YAML);
                $prefix = $total->get("prefix");
                $player->setDisplayName($prefix.$player->getName());
                $player->setNameTag($prefix.$player->getName()); }
                elseif(($r=="Guardian")||($r=="guardian")){
                  $total = new Config($this->getDataFolder()."/Config/Guardian.yml", Config::YAML);
                  $prefix = $total->get("prefix");
                  $player->setDisplayName($prefix.$player->getName());
                  $player->setNameTag($prefix.$player->getName());  }
        else {
          $player->setDisplayName("§8[§aUser§8] §7".$player->getName());
          $player->setNameTag("§8[§aUser§8] §7".$player->getName());
        }
}

public function Pytranks($player) {

    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $r = $rank->get($player->getName());
    $srank = new Config($this->getDataFolder() . "/srank.yml", Config::YAML);
    $sr = $srank->get($player->getName());

    if(($sr=="MiniYT")||($sr=="miniyt")){
      $total = new Config($this->getDataFolder()."/Config/MiniYT.yml", Config::YAML);
      $prefix = $total->get("prefix");
      $player->setNameTag($prefix.$player->getDisplayName());      }
      elseif (($sr=="youtube")||($sr=="YouTube")||($sr=="youtuber")||($sr=="YouTuber")) {
        $total = new Config($this->getDataFolder()."/Config/YouTuber.yml", Config::YAML);
        $prefix = $total->get("prefix");
        $player->setNameTag($prefix.$player->getDisplayName());      }
        elseif (($sr=="famous")||($sr=="Famous")) {
          $total = new Config($this->getDataFolder()."/Config/Famous.yml", Config::YAML);
          $prefix = $total->get("prefix");
          $player->setNameTag($prefix.$player->getDisplayName());      }
  }

}

 ?>
