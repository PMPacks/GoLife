<?php

namespace Buyec;

use pocketmine\{Server, Player};
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use jojoe77777\FormAPI;

Class Main extends PluginBase implements Listener{

 public function onEnable(){
   $this->getServer()->getPluginManager()->registerEvents($this, $this);
     
   $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");  
   $this->getLogger()->info("§l§e→§b Buyec Write By Phuongaz");
   $this->getLogger()->info("§l§e→§b Buyec Edit Lại Bởi MamChamPlu");
   $this->getLogger()->info("§l§e→§b Sẽ Kích Hoạt Ngay Sau Khi Server Chạy Hoàn Tất");

 }
   
   public function onCommand(CommandSender $sender, Command $cmd, string $label, $args):bool{
   if(!$sender instanceof Player){
     $sender->sendMessage("Bạn Không Phải Là Người Chơi");
	 $sender->sendMessage("Bạn Đéo Có Quyền Sử Dụng Lệnh Ở Đây");
	 $sender->sendMessage("OK BABY!");
     return true;
     }
     switch($cmd->getName()){
        case "buyec":
     if (!isset($args[0]))		
		{
		$sender->sendMessage("§l§e→§aSử Dụng Lệnh: §e/buyec [id] [Level]");
		$sender->sendMessage("§l§e→§eMỗi Cấp Là 10000 Xu Nha Mấy Bạn");
		$sender->sendMessage("§l§e→§cLưu Ý: Nâng Cấp sẽ Không Có Cộng Dồn Đâu Nhé!");
			return true;
	 }

        $price = 10000;
        $maxlevel = 8;
     if(!isset($args[0]) && isset($args[1])) {
       $sender->sendMessage("§l§c/buyec <id> <level>");
       $sender->sendMessage("§l§c/listec 1/2");
	   return true;
       }else{
        if(!is_numeric($args[0]) and is_numeric($args[1])){
        $sender->sendMessage("§cID Nâng Cấp Chỉ Đạt 1 Giới Hạn Nào Đó");
        return true;
        }
       if($sender->getInventory()->getIteminHand()->getId() == 0){
        $sender->sendMessage("Không Có Vật Phẩm Nâng Cấp Trên Tay");
        return true;
        }
        $moneytype = $args[1] * $price;
        if($this->eco->myMoney($sender->getName()) < $moneytype){
        $sender->sendMessage("§cBạn Cần Có Tiền Để Mua Nhé");
        }else{
         if($args[1] > $maxlevel){
          $sender->sendMessage("§l§6Cấp Cao Nhất Hiện Tại Là: ".$maxlevel);
          }else{
            if($args[0] > 24 && $args[0] < 0){
            $sender->sendMessage("§l§cID Nâng Cấp Này Không Có Trong Cửa Hàng");
            }else{
        $item = $sender->getInventory()->getIteminHand();
       $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment($args[0]), $args[1]));
        $sender->getInventory()->setIteminHand($item);
        $this->eco->reduceMoney($sender->getName(), $moneytype);
        $sender->sendMessage("§b§lĐã Mua Thành Công Phép Thuật Này");
		return true;
}
      } 
         }
	   }
        break;
        case "listec":
             $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
						$form = $api->createCustomForm(function (Player $player, $data){
                });
				
$form->setTitle("Khu Lấy ID Nâng Cấp");
$form->addLabel("§6Sử Dụng:§f/buyec [id] [level] trong đó §6ID§f là mục enchant có sẵn bên dưới");
   $form->addLabel("§l§e
   §a0:§eBảo vệ
   ----------------
   §a1: §eBảo vệ khỏi lửa
   ----------------
   §a2: §eRơi nhẹ như lông chim
   ----------------
   §a3: §eBảo vệ khỏi vụ nổ
   ----------------
   §a4: §eBảo vệ khỏi vật được bắn
   ----------------
   §a5: §eGai
   ----------------
   §a6: §eHô hấp
   ----------------
   §a7: §eSải chân dưới nước
   ----------------
   §a8: §eÁp lực với nước
   ----------------
   §a9: §eSắc bén
   ----------------
   §a10: §eHại thây ma
   ----------------
   §a11: §eHại chân đốt
   ----------------
   §a12: §eBật lùi
   ----------------
   §a13: §eKhía cạnh của lửa
   ----------------
   §a14: §eNhặt
   ----------------
   §a15: §eHiệu xuất
   ----------------
   §a16: §eMềm mại
   ----------------
   §a17: §eKhông bị phá vở
   ----------------
   §a18: §eGia tài
   ----------------
   §a19: §eSức Mạnh
   ----------------
   §a20: §eĐấm
   ----------------
   §a21: §eLửa
   ----------------
   §a22: §eVô Hạn
   ----------------
   §a23: §eMay mắn
   ----------------
   §a24: §eNhử
   ----------------");
   $form->sendToPlayer($sender);
   
      return true;
			}
        }
}    