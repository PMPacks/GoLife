# SELLHAND
### Originally created by @Muqsit. Fixed for PocketMine-MP 1.2 by @JackMD, and partley by VMPE Development Team
#### An essential plugin for all Faction and Prison based servers.
##### How to use?
- Make sure you have the popular ```EconomyAPI``` plugin by onebone installed.
- Download the plugin. Phar can be found [here](https://poggit.pmmp.io/ci/ZPlayzMCPE/Sell).
- Start the server.
- Stop the server.
- Go to plugins -> Sell and open the ```sell.yml``` file.
- Configure the ```sell.yml``` file as you wish.
- Start the server.
- Now hold an item in your hand. (Eg: Diamond Sword).
- Run the command ```/sell hand```.
- TIP: If you want to sell everything that is possible to sell, run ```/sell all```.
- If the item you are holding is configured in ```sell.yml```, the item you are holding will be sold.
