<?php

namespace MamChamPlu;

#Server Player
use pocketmine\{Server, Player};
#Base
use pocketmine\plugin\PluginBase;
#Event
use pocketmine\event\Listener;
#TextFormat
use pocketmine\utils\TextFormat;
#COMMAND
use pocketmine\command\{Command, CommandSender, CommandExecutor, ConsoleCommandSender};
#PACKET
use pocketmine\event\server\DataPacketReceiveEvent;
#API
use jojoe77777\FormAPI;

class Main extends PluginBase implements Listener {
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§cPlugin §bInfoUI §cBy MamChamPlu\n\n §ePlugin §bInfo §6Đã Kích Hoạt");
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, $args): bool {
		$player = $sender->getPlayer();
		switch($cmd->getName()){
			case "buyec":
$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $formapi->createCustomForm(function (Player $event, $data){
				$result = $data[0];
				$sender = $event->getPlayer();
				if($result != null){
					$this->ID = $data[0];
					$this->Level = $data[1];
					$this->getServer()->getCommandMap()->dispatch($sender, "buyenchant " . $this->ID." ".$this->Level);
				}
			});
			$form->setTitle("§c§lBUY ENCHANTS ");
	$form->addInput("§b[§d+§b]§6 -> §eID Lấy Trong §6/listec");
		$form->addInput("§b[§d+§b]§6 -> §eLevel Là Cấp Độ ENCHANTS Tối Đa Là§6 8 ");
			$form->sendToPlayer($sender);
			break;		
		}
		return true;
	}
}
