# PMchair_Fork_of_others
こちらから拝借(ForkのForkはできなかった)
https://github.com/SOLOPlugins-PocketMine/PmChair  
ビルド用
