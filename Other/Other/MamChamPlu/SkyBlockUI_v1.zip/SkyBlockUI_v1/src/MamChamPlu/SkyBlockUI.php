<?php

namespace MamChamPlu;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use jojoe77777\FormAPI;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;

class SkyBlockUI extends PluginBase implements Listener {
    
    public function onEnable(){
        $this->getLogger()->info("- SkyBlockUI Enabled! by MamChamPlu");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->checkDepends();
    }

    public function checkDepends(){
        $this->formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        if(is_null($this->formapi)){
            $this->getLogger()->info("§4Hãy Cài Plugin FormAPI Để Được Trải Nghiệm");
            $this->getPluginLoader()->disablePlugin($this);
        }
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args):bool
    {
        switch($cmd->getName()){
        case "sb":
        if(!($sender instanceof Player)){
                $sender->sendMessage("§7không sửa dụng được lệnh ở console!");
				$sender->sendMessage("§b->§6 Bạn Đéo Có Quyền Sử Dụng Lệnh Ở Đây");
				$sender->sendMessage("§b->§6 Không Có Máy Chơi Thì Cút Đéo Tiếp");
				$sender->sendMessage("§b->§6 OK BABY!");
                return true;
        }
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, $data){
            $result = $data;
            if ($result == null) {
            }
            switch ($result) {
                    case 0:
                        break;
                    case 1:
					$command = "skyblock help";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);                       
					    break;
                    case 2:
					$command = "warp SkyBlock";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                    $command = "skyblock auto";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);
					$command = "skyblock claim";
								$this->getServer()->getCommandMap()->dispatch($sender, $command);
					$sender->addTitle("§aGhost§6Royal", "§e/sb và nhập Claim");
						break;
                    case 3:
					$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $formapi->createCustomForm(function (Player $event, $data){
				$result = $data[0];
				$sender = $event->getPlayer();
				if($result != null){
					$this->Warp = $data[0];
					$this->getServer()->getCommandMap()->dispatch($sender, "skyblock warp " . $this->Warp);
				}
			});
			$form->setTitle("§cWARP §aSKY§eBLOCK");
			
			$form->addInput("§eĐịnh Dạng Là §6X;Y §eNhé");
			$form->sendToPlayer($sender);
			break;
                    case 4:
                    $formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $formapi->createCustomForm(function (Player $event, $data){
				$result = $data[0];
				$sender = $event->getPlayer();
				if($result != null){
					$this->addhelp = $data[0];
					$this->getServer()->getCommandMap()->dispatch($sender, "skyblock addhelper " . $this->addhelp);
				}
			});
			$form->setTitle("§aADDHELPER §aSKY§eBLOCK");
			$form->addInput("§eTên Người Muốn Thêm Vào §6Đảo");
			$form->addLabel("§b[§a+§b] §6->§e Ghi Tên Phía Dưới Để Thêm Người Chơi Khác Vào Đảo");
			$form->sendToPlayer($sender);
			
			            break;
					case 5:
					$formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $formapi->createCustomForm(function (Player $event, $data){
				$result = $data[0];
				$sender = $event->getPlayer();
				if($result != null){
					$this->removehelp = $data[0];
					$this->getServer()->getCommandMap()->dispatch($sender, "skyblock removehelper " . $this->removehelp);
				}
			});
			$form->setTitle("§cREMOVEHELPER §aSKY§eBLOCK");
			$form->addInput("§eTên Người Muốn Xóa Khỏi §6Đảo");
			$form->addLabel("§b[§a+§b] §6->§e Ghi Tên Phía Dưới Để Xóa Người Chơi Khác Khỏi Đảo");
			$form->sendToPlayer($sender);			
			            break;
					case 6:
                    $command = "skyblock info";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                        break;
					case 7:
					$command = "warp SkyBlock";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                    $command = "skyblock home";
								$this->getServer()->getCommandMap()->dispatch($sender, $command);
                        break;
					case 8:
					$command = "skyblock homes";
					            $this->getServer()->getCommandMap()->dispatch($sender, $command);
						break;		
            }
        });
        $form->setTitle("§l§aSky§bBlock");
        $form->setContent("§e§l→§a§lGhost§6Royal §eSB");
        $form->addButton("§6§lBack To §eMENU", 0);
        $form->addButton("§l§6HELP", 1);
        $form->addButton("§l§6AUTO §6AND §6CLAIM", 2);
        $form->addButton("§l§6WARP", 3);
        $form->addButton("§l§6ADDHELPER", 4);
		$form->addButton("§l§cREMOVEHELPER", 5);
		$form->addButton("§l§6INFO", 6);
		$form->addButton("§l§6HOME", 7);
		$form->addButton("§l§6HOMES", 8);
        $form->sendToPlayer($sender);
        }
        return true;
    }

    public function onDisable(){
        $this->getLogger()->info("- SkyBlockUI Đã Bị Lỗi Và Ngắt Kết Nối!");
    }
}
