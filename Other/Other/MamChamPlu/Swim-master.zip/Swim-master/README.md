# Swim
Swim in MCPE!

How to swim?
Just go in the water and goooogogogo!!!!
