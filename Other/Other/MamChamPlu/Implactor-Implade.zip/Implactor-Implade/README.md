![start2](https://cdn.discordapp.com/attachments/442624759985864714/454906888472231946/ReadMD.png)

| Poggit | Hit Counts | License |
| :-----: | :-----: | :-----: |
[![Poggit-CI](https://poggit.pmmp.io/ci.badge/ImpladeDeveloped/Implactor/Implactor/Implade)](https://poggit.pmmp.io/ci/ImpladeDeveloped/Implactor) | [![HitCount](http://hits.dwyl.io/ImpladeDeveloped/Implactor.svg)](http://hits.dwyl.io/ImpladeDeveloped/Implactor) | [![Implactor License](https://img.shields.io/github/license/ImpladeDeveloped/Implactor.svg?label=License)](LICENSE)

## Implactor
A [PocketMine](http://github.com/pmmp/PocketMine-MP) plugin as a cool classic core<br>
with more added authorized features and UIs to there!

### License
This plugin is licensed under GNU General Public License v3.0!<br>
It is free to use, copyleft license for software and other<br>
kinds of works.

### Permissions
A good plugin developer, [FreeGamingHere](http://github.com/FreeGamingHere) has gave me a permissions<br>
to added his codes to Implactor by making a improvements and combined!<br>
It is currently now authorized from plugin developers.

### Credits
> This plugin was officialy created on ***23 May 2018***<br>
> and it's authored by [Zadezter](http://github.com/Zadezter)

### Preview
**__Check out my official video posted on YouTube!__**

[![Implactor](http://img.youtube.com/vi/A7jcrM26Clk/0.jpg)](http://www.youtube.com/watch?v=A7jcrM26Clk "")
