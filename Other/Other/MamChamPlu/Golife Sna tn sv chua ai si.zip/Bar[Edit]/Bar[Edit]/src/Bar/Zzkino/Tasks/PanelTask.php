<?php

namespace Bar\Zzkino\Tasks;

use pocketmine\Server;
use pocketmine\scheduler\Task;
use Bar\Zzkino\Main;
use pocketmine\plugin\Plugin;

class PanelTask extends PluginTask{

    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        pare;
    }

    onRun(int $currentTicks) :void{
		$this->plugin->onPanel();
    }

	public function cancel(){
      $this->getHandler()->cancel();
   }

}
