<?php

namespace MamChamPlu\CaiDat;

abstract class BaseModule{
	
	private static $plugin = null;
	
	/**
	 * @param superBAR $plugin
	 */
	public static function setPlugin(CaiDat $plugin){
		BaseModule::$plugin = $plugin;
	}
	
	/**
	 * @return superBAR|null
	 */
	protected function getPlugin(): CaiDat{
		return BaseModule::$plugin;
	}
}
