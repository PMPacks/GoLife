<?php

namespace MamChamPlu\CaiDat;

use pocketmine\scheduler\Task;

class LoaderTask extends Task{
	
	private $loader;
	
	/**
	 * LoaderTask constructor.
	 *
	 * @param superBAR $plugin
	 * @param Loader   $loader
	 */
	public function __construct(CaiDat $plugin, Loader $loader){
		$this->loader = $loader;
	}
	
	/**
	 * @param int $tick
	 */
	public function onRun(int $tick){
		$this->loader->onEnable();
	}
	
}
