<?php

namespace tung;

use pocketmine\plugin\Plugin;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\block\BlockFactory;
use pocketmine\block\Block;

class IceTask4 extends Task{

	private $owner;
    public $level;
    public $pos;
    public $meta;
    public $id;

	public function __construct(Plugin $owner,$level,$pos,$meta,$id){
		$this->owner = $owner;
		$this->level = $level;
		$this->pos = $pos;
        $this->meta = $meta;
        $this->id = $id;
	}
	public function onRun($tick){
        $this->level->setBlock($this->pos->add(0,0,0),Block::get(0));
        $this->level->setBlock($this->pos->add(0,0,1),Block::get(0));
        $this->level->setBlock($this->pos->add(0,0,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(1,0,0),Block::get(0));
        $this->level->setBlock($this->pos->add(1,0,1),Block::get(0));
        $this->level->setBlock($this->pos->add(1,0,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(2,0,0),Block::get(0));
        $this->level->setBlock($this->pos->add(2,0,1),Block::get(0));
        $this->level->setBlock($this->pos->add(2,0,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(3,0,0),Block::get(0));
        $this->level->setBlock($this->pos->add(3,0,1),Block::get(0));
        $this->level->setBlock($this->pos->add(3,0,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(4,1,0),Block::get(0));
        $this->level->setBlock($this->pos->add(4,1,1),Block::get(0));
        $this->level->setBlock($this->pos->add(4,1,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(5,1,0),Block::get(0));
        $this->level->setBlock($this->pos->add(5,1,1),Block::get(0));
        $this->level->setBlock($this->pos->add(5,1,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(6,1,0),Block::get(0));
        $this->level->setBlock($this->pos->add(6,1,1),Block::get(0));
        $this->level->setBlock($this->pos->add(6,1,-1),Block::get(0));
        $this->level->setBlock($this->pos->add(7,1,0),Block::get(0));
        $this->level->setBlock($this->pos->add(7,1,1),Block::get(0));
        $this->level->setBlock($this->pos->add(7,1,-1),Block::get(0));
        $this->cancel();
	}
    public function cancel() {
        $this->getHandler()->cancel();
    }
}