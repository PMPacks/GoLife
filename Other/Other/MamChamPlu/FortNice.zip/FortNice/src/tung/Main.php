<?php
namespace tung;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\sound\GhastSound as A;
use pocketmine\level\particle\FlameParticle as B;


use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\entity\Entity;
use pocketmine\block\Block;
use pocketmine\event\block\BlockPlaceEvent; 
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;

class Main extends PluginBase  implements Listener{

    public $deltime = 60;

    public function onEnable(){
	     $this->getServer()->getPluginManager()->registerEvents($this, $this);
	     $this->getLogger()->info("Fortnice");
  }
    public function onInteract(PlayerInteractEvent $e){
        $player = $e->getPlayer();
        $level = $player->getLevel();
        if($e->getItem()->getId() == 369){
            $nbt = new CompoundTag("", [
                "Pos" => new ListTag("Pos", [
                    new DoubleTag("", $player->x),
                    new DoubleTag("", $player->y + $player->getEyeHeight()),
                    new DoubleTag("", $player->z)
                ]),
                "Motion" => new ListTag("Motion", [
                    new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                    new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                    new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI))
                ]),
                "Rotation" => new ListTag("Rotation", [
                    new FloatTag("", $player->yaw),
                    new FloatTag("", $player->pitch)
                ]),
            ]);
            $f = 2;
            $tnt = Entity::createEntity("PrimedTNT", $level, $nbt, true);
            $tnt->setMotion($tnt->getMotion()->multiply($f));
            $tnt->spawnTo($player);
            $e->getPlayer()->getInventory()->removeItem(Item::get($e->getItem()->getId(),0,1));
        }
    }

    public function blockplace(BlockPlaceEvent $event){
     $id = $event->getBlock()->getID();	  
     $block = $event->getBlock();
     $player = $event->getPlayer();
     $level = $player->getLevel();
	 $x = $block->getX();
	 $y = $block->getY();
	 $z = $block->getZ();
	 $pos = new Vector3($x,$y,$z);
	 $direc = $player->getDirection();
	 $faces = [
	   0=>0,
	   1=>2,
	   2=>1,
	   3=>3,
	 ];
	 $meta = $this->meta = $faces[$direc] & 0x03;
	 //Tnt----------------------------------------
     if($id == 46){
         $level->setBlock($pos,Block::get(0));
         $nbt = new CompoundTag("", [
             "Pos" => new ListTag("Pos", [
                 new DoubleTag("", $player->x),
                 new DoubleTag("", $player->y + $player->getEyeHeight()),
                 new DoubleTag("", $player->z)
             ]),
             "Motion" => new ListTag("Motion", [
                 new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                 new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                 new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI))
             ]),
             "Rotation" => new ListTag("Rotation", [
                 new FloatTag("", $player->yaw),
                 new FloatTag("", $player->pitch)
             ]),
         ]);
         $f = 1;
         $tnt = Entity::createEntity("PrimedTNT", $level, $nbt, true);
         $tnt->setMotion($tnt->getMotion()->multiply($f));
         $tnt->spawnTo($player);
     }
	 //CauThang-------------------------------------
	 if($id == 163){
         $event->getPlayer()->getInventory()->removeItem(Item::get($id,0,1));
      switch ($direc){
       case 1:		  
 	      //floor1
	      $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	      //floor2
           $level->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
           $level->setBlock($pos->add(1,1,1),Block::get($id,$this->meta));
           $level->setBlock($pos->add(-1,1,1),Block::get($id,$this->meta));
          //floor3
           $level->setBlock($pos->add(0,2,2),Block::get($id,$this->meta));
           $level->setBlock($pos->add(1,2,2),Block::get($id,$this->meta));
           $level->setBlock($pos->add(-1,2,2),Block::get($id,$this->meta));
	      //floor4
           $level->setBlock($pos->add(0,3,3),Block::get($id,$this->meta));
           $level->setBlock($pos->add(1,3,3),Block::get($id,$this->meta));
           $level->setBlock($pos->add(-1,3,3),Block::get($id,$this->meta));
	      //Floor
           $level->setBlock($pos->add(0,3,4),Block::get(5));
           $level->setBlock($pos->add(1,3,4),Block::get(5));
           $level->setBlock($pos->add(-1,3,4),Block::get(5));
           //DeleteAllFloor
           $this->getScheduler()->scheduleDelayedTask(new StairTask1($this,$level,$pos,$meta,$id),$this->deltime);
          break;
	   case 0:
	      //floor1
	      $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
          $level->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	      //floor2
	      $level->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(1,1,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $level->setBlock($pos->add(2,2,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(2,2,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(2,2,-1),Block::get($id,$this->meta));
	      //floor4
	      $level->setBlock($pos->add(3,3,0),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(3,3,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(3,3,-1),Block::get($id,$this->meta));
	      //Floor
	      $level->setBlock($pos->add(4,3,0),Block::get(5));
	      $level->setBlock($pos->add(4,3,1),Block::get(5));
	 	  $level->setBlock($pos->add(4,3,-1),Block::get(5));
          //DeleteAllFloor
           $this->getScheduler()->scheduleDelayedTask(new StairTask2($this,$level,$pos,$meta,$id),$this->deltime);
	 	  break;
	   case 2:
	      $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
          $level->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	      //floor2
	      $level->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-1,1,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $level->setBlock($pos->add(-2,2,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(-2,2,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-2,2,-1),Block::get($id,$this->meta));
	      //floor4
	      $level->setBlock($pos->add(-3,3,0),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-3,3,1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-3,3,-1),Block::get($id,$this->meta));
	      //Floor
	      $level->setBlock($pos->add(-4,3,0),Block::get(5));
	      $level->setBlock($pos->add(-4,3,1),Block::get(5));
	 	  $level->setBlock($pos->add(-4,3,-1),Block::get(5));
           //DeleteAllFloor
           $this->getScheduler()->scheduleDelayedTask(new StairTask3($this,$level,$pos,$meta,$id),$this->deltime);
          break;       
	   case 3:
 	      //floor1
	      $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
          $level->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	      //floor2
	      $level->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(1,1,-1),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $level->setBlock($pos->add(0,2,-2),Block::get($id,$this->meta));
          $level->setBlock($pos->add(1,2,-2),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-1,2,-2),Block::get($id,$this->meta));
	      //floor4
	      $level->setBlock($pos->add(0,3,-3),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(1,3,-3),Block::get($id,$this->meta));
	      $level->setBlock($pos->add(-1,3,-3),Block::get($id,$this->meta));
	      //Floor
	      $level->setBlock($pos->add(0,3,-4),Block::get(5));
	      $level->setBlock($pos->add(1,3,-4),Block::get(5));
	 	  $level->setBlock($pos->add(-1,3,-4),Block::get(5));
           //DeleteAllFloor
           $this->getScheduler()->scheduleDelayedTask(new StairTask4($this,$level,$pos,$meta,$id),$this->deltime);
	      break;

	  }
	}
	 //Iron------------------------------
	 if($id == 101){
	  switch($direc){
       case 1:		  
	     $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,2,0),Block::get($id,$this->meta));
		 $level->setBlock($pos->add(-1,2,0),Block::get($id,$this->meta));
	     break;		 
       case 3:		  
	     $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(1,2,0),Block::get($id,$this->meta));
		 $level->setBlock($pos->add(-1,2,0),Block::get($id,$this->meta));
	     break;		 		 
	   case 0:
	     $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,1),Block::get($id,$this->meta));
	     break;
	   case 2:
	     $level->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,0),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,-1),Block::get($id,$this->meta));
	     $level->setBlock($pos->add(0,2,1),Block::get($id,$this->meta));
	     break;	  
	  }
	 }
	 //Duongdibangkinh------------------
     if($id == "241:3"){
         $event->getPlayer()->getInventory()->removeItem(Item::get($id,0,1));
	 switch($direc){	
      case 1:
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),0);
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),1);
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),2);
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),6);
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),8);
          $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),10);
	  $level->setBlock($pos->add(0,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,1),Block::get(241,3));
	  $level->setBlock($pos->add(-1,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(0,0,1),Block::get(241,3));
      $level->setBlock($pos->add(0,0,2),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,2),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,2),Block::get(241,3));
	  $level->setBlock($pos->add(0,0,3),Block::get(241,3));
	  $level->setBlock($pos->add(-1,0,3),Block::get(241,11));
	  $level->setBlock($pos->add(1,0,3),Block::get(241,3));
          $level->setBlock($pos->add(0,1,4),Block::get(241,3));
          $level->setBlock($pos->add(1,1,4),Block::get(241,11));
          $level->setBlock($pos->add(-1,1,4),Block::get(241,3));
          $level->setBlock($pos->add(1,1,5),Block::get(241,3));
          $level->setBlock($pos->add(-1,1,5),Block::get(241,11));
          $level->setBlock($pos->add(0,1,5),Block::get(241,3));
          $level->setBlock($pos->add(0,1,6),Block::get(241,11));
          $level->setBlock($pos->add(-1,1,6),Block::get(241,3));
          $level->setBlock($pos->add(1,1,6),Block::get(241,3));
          $level->setBlock($pos->add(0,1,7),Block::get(241,3));
          $level->setBlock($pos->add(-1,1,7),Block::get(241,11));
          $level->setBlock($pos->add(1,1,7),Block::get(241,3));
       $this->getScheduler()->scheduleDelayedTask(new IceTask1($this,$level,$pos,$meta,$id),$this->deltime);
	  break;
	 case 3:
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),0);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),1);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),2);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),6);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),8);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),10);
	  $level->setBlock($pos->add(0,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,-1),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,-1),Block::get(241,11));
	  $level->setBlock($pos->add(0,0,-1),Block::get(241,3));
      $level->setBlock($pos->add(0,0,-2),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,-2),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,-2),Block::get(241,3));
	  $level->setBlock($pos->add(0,0,-3),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,-3),Block::get(241,11));
	  $level->setBlock($pos->add(1,0,-3),Block::get(241,3));
         $level->setBlock($pos->add(0,1,-4),Block::get(241,3));
         $level->setBlock($pos->add(1,1,-4),Block::get(241,11));
         $level->setBlock($pos->add(-1,1,-4),Block::get(241,3));
         $level->setBlock($pos->add(1,1,-5),Block::get(241,11));
         $level->setBlock($pos->add(-1,1,-5),Block::get(241,11));
         $level->setBlock($pos->add(0,1,-5),Block::get(241,3));
         $level->setBlock($pos->add(0,1,-6),Block::get(241,11));
         $level->setBlock($pos->add(-1,1,-6),Block::get(241,3));
         $level->setBlock($pos->add(1,1,-6),Block::get(241,3));
         $level->setBlock($pos->add(0,1,-7),Block::get(241,11));
         $level->setBlock($pos->add(-1,1,-7),Block::get(241,11));
         $level->setBlock($pos->add(1,1,-7),Block::get(241,3));
         $this->getScheduler()->scheduleDelayedTask(new IceTask2($this,$level,$pos,$meta,$id),$this->deltime);
      break;
	 case 2:
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),0);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),1);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),2);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),6);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),8);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),10);
	  $level->setBlock($pos->add(0,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(0,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(0,0,-1),Block::get(241,3));
	  $level->setBlock($pos->add(-1,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(-1,0,1),Block::get(241,3));
	  $level->setBlock($pos->add(-1,0,-1),Block::get(241,11));
      $level->setBlock($pos->add(-2,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(-2,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(-2,0,-1),Block::get(241,3));
	  $level->setBlock($pos->add(-3,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(-3,0,1),Block::get(241,3));
	  $level->setBlock($pos->add(-3,0,-1),Block::get(241,11));
         $level->setBlock($pos->add(-4,1,0),Block::get(241,11));
         $level->setBlock($pos->add(-4,1,1),Block::get(241,11));
         $level->setBlock($pos->add(-4,1,-1),Block::get(241,3));
         $level->setBlock($pos->add(-5,1,0),Block::get(241,11));
         $level->setBlock($pos->add(-5,1,1),Block::get(241,3));
         $level->setBlock($pos->add(-5,1,-1),Block::get(241,11));
         $level->setBlock($pos->add(-6,1,0),Block::get(241,3));
         $level->setBlock($pos->add(-6,1,1),Block::get(241,11));
         $level->setBlock($pos->add(-6,1,-1),Block::get(241,3));
         $level->setBlock($pos->add(-7,1,0),Block::get(241,11));
         $level->setBlock($pos->add(-7,1,1),Block::get(241,3));
         $level->setBlock($pos->add(-7,1,-1),Block::get(241,11));
         $this->getScheduler()->scheduleDelayedTask(new IceTask3($this,$level,$pos,$meta,$id),$this->deltime);
      break;
	 case 0:
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),0);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),1);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),2);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),6);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),8);
         $this->getScheduler()->scheduleDelayedTask(new Sound1($this,$level,$player),10);
	  $level->setBlock($pos->add(0,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(0,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(0,0,-1),Block::get(241,3));
	  $level->setBlock($pos->add(1,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(1,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(1,0,-1),Block::get(241,3));
      $level->setBlock($pos->add(2,0,0),Block::get(241,11));
	  $level->setBlock($pos->add(2,0,1),Block::get(241,3));
	  $level->setBlock($pos->add(2,0,-1),Block::get(241,11));
	  $level->setBlock($pos->add(3,0,0),Block::get(241,3));
	  $level->setBlock($pos->add(3,0,1),Block::get(241,11));
	  $level->setBlock($pos->add(3,0,-1),Block::get(241,3));
         $level->setBlock($pos->add(4,1,0),Block::get(241,11));
         $level->setBlock($pos->add(4,1,1),Block::get(241,11));
         $level->setBlock($pos->add(4,1,-1),Block::get(241,3));
         $level->setBlock($pos->add(5,1,0),Block::get(241,11));
         $level->setBlock($pos->add(5,1,1),Block::get(241,3));
         $level->setBlock($pos->add(5,1,-1),Block::get(241,11));
         $level->setBlock($pos->add(6,1,0),Block::get(241,3));
         $level->setBlock($pos->add(6,1,1),Block::get(241,11));
         $level->setBlock($pos->add(6,1,-1),Block::get(241,3));
         $level->setBlock($pos->add(7,1,0),Block::get(241,11));
         $level->setBlock($pos->add(7,1,1),Block::get(241,3));
         $level->setBlock($pos->add(7,1,-1),Block::get(241,11));
         $this->getScheduler()->scheduleDelayedTask(new IceTask4($this,$level,$pos,$meta,$id),$this->deltime);
	  break;
	 }
   }     
  }	 
}
