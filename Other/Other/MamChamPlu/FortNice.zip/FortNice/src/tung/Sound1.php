<?php

namespace tung;

use pocketmine\plugin\Plugin;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;

class Sound1 extends Task{

	private $owner;
    public $level;
    public $player;

	public function __construct(Plugin $owner,$level,$player){
		$this->owner = $owner;
		$this->level = $level;
		$this->player = $player;
	}
	public function onRun($tick){
        $this->level->broadcastLevelSoundEvent($this->player,127);
        $this->cancel();
	}
    public function cancel() {
        $this->getHandler()->cancel();
    }
}